
-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_07_25_212252_create_appointment_table', 1),
(2, '2021_07_25_212252_create_check_in_student_table', 1),
(3, '2021_07_25_212252_create_checkin_date_daily_table', 1),
(4, '2021_07_25_212252_create_checkin_setup_table', 1),
(5, '2021_07_25_212252_create_failed_jobs_table', 1),
(6, '2021_07_25_212252_create_installments_table', 1),
(7, '2021_07_25_212252_create_move_appointment_table', 1),
(8, '2021_07_25_212252_create_payment_settings_table', 1),
(9, '2021_07_25_212252_create_payments_table', 1),
(10, '2021_07_25_212252_create_stations_table', 1),
(11, '2021_07_25_212252_create_subscribes_table', 1),
(12, '2021_07_25_212252_create_terms_table', 1),
(13, '2021_07_25_212252_create_user_group_table', 1),
(14, '2021_07_25_212252_create_users_table', 1),
(15, '2021_07_25_212255_add_foreign_keys_to_installments_table', 1),
(16, '2021_07_25_212255_add_foreign_keys_to_subscribes_table', 1),
(17, '2021_08_03_215318_create_appointment_table', 0),
(18, '2021_08_03_215318_create_check_in_student_table', 0),
(19, '2021_08_03_215318_create_checkin_date_daily_table', 0),
(20, '2021_08_03_215318_create_checkin_setup_table', 0),
(21, '2021_08_03_215318_create_failed_jobs_table', 0),
(22, '2021_08_03_215318_create_installments_table', 0),
(23, '2021_08_03_215318_create_move_appointment_table', 0),
(24, '2021_08_03_215318_create_payment_settings_table', 0),
(25, '2021_08_03_215318_create_payments_table', 0),
(26, '2021_08_03_215318_create_stations_table', 0),
(27, '2021_08_03_215318_create_subscribes_table', 0),
(28, '2021_08_03_215318_create_terms_table', 0),
(29, '2021_08_03_215318_create_user_group_table', 0),
(30, '2021_08_03_215318_create_users_table', 0),
(31, '2021_08_03_215324_add_foreign_keys_to_installments_table', 0),
(32, '2021_08_03_215324_add_foreign_keys_to_subscribes_table', 0);
