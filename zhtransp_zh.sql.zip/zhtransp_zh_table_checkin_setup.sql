
-- --------------------------------------------------------

--
-- Table structure for table `checkin_setup`
--

CREATE TABLE `checkin_setup` (
  `setup_id` int UNSIGNED NOT NULL,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `checkin_setup`
--

INSERT INTO `checkin_setup` (`setup_id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'مش هرجع معاكو ❌', 1, '2021-09-11 02:29:54', '2021-10-23 13:37:37'),
(2, 'لسه مش عارف ⬅️ ليك مكان فى المعاد الفاضى فقط', 1, '2021-09-11 02:30:14', '2021-10-29 12:39:04'),
(3, '8 ➡️ 4:00 pm بس هتاخر شوية', 1, '2021-09-11 02:30:26', '2022-05-07 08:11:41'),
(4, '7 ➡️ 4:00 pm', 1, '2021-09-18 22:17:01', '2022-05-07 08:11:24'),
(5, '6 ➡️ 3:00 pm', 1, '2021-09-18 22:17:14', '2022-04-01 17:17:34'),
(6, '5 ➡️ 2:00 pm', 1, '2021-09-23 20:08:54', '2022-04-01 17:17:14'),
(7, '4 ➡️ 1:00 pm', 1, '2021-09-24 08:12:23', '2022-04-01 17:17:01'),
(8, '3 ➡️ 12:00 pm', 1, '2021-09-24 08:16:26', '2022-04-01 17:16:32'),
(9, '2 ➡️ 11:00 am', 0, '2021-09-24 08:19:12', '2022-05-07 08:12:04'),
(10, '1 ➡️ 10:00 am', 0, '2021-09-24 08:26:09', '2022-05-07 08:11:58');
