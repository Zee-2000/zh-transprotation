 
-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int UNSIGNED NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `name` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `start_date`, `end_date`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, '2021-10-30', '2022-01-01', 'demo 22', 0, '2021-07-29 15:36:52', '2022-04-20 22:36:23'),
(2, '2021-10-09', '2022-02-10', 'ترم اول 2022', 0, '2021-08-09 18:22:29', '2022-04-20 22:36:23'),
(3, '2022-01-09', '2022-01-27', 'demo 2', 0, '2021-08-26 17:40:34', '2022-04-20 22:36:23'),
(4, '2022-02-19', '2022-07-30', 'ترم تانى2022', 1, '2022-01-31 21:25:21', '2022-04-20 22:36:23');
